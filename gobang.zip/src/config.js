import WhitePng from './images/white.png';
import BlackPng from './images/black.png';

export const CAMP = {
  WHITE: 0,
  BLACK: 1,
  NONE: 2
}

const CAMP_IMAGE = [
  WhitePng,
  BlackPng
]

const CAMPS = [
  CAMP.WHITE,
  CAMP.BLACK
];

export function getNextCamp(nowCamp) {
  return CAMPS[(nowCamp + 1) % CAMPS.length];
} 

export function getCampImage(camp) {
  return CAMP_IMAGE[camp] || null;
}
