import { useCallback, useEffect, useMemo, useState } from "react";
import BoardStatebar from "../BoardStatebar";
import { CAMP, getNextCamp } from '../../config';
import Grid from "../Grid";

import './Board.css';

function getRandomPos(grids) {
  while (true) {
    const index = Math.floor(Math.random() * grids.length);

    if (grids[index] === CAMP.NONE) {
      return index;
    }
  }

  return -1;
}

function judgeVictoryInPoint(grids, startPoint) {
  // 横竖撇捺
  const rules = [1, 14, 15, 16];

  for (let rule of rules) {
    const winnerPath = judgeDirectionStateInPoint(grids, startPoint, rule);
    if (winnerPath.length >= 5) {
      return winnerPath;
    }
  }

  return null;
}

function judgeDirectionStateInPoint(grids, startPoint, step) {
  const points = [startPoint];
  const startPointCamp = grids[startPoint];

  for (let index = startPoint - step; index >= 0; index -= step) {
    if (grids[index] !== startPointCamp) {
      break;
    }
    points.push(index);
  }

  for (let index = startPoint + step; index < grids.length; index += step) {
    if (grids[index] !== startPointCamp) {
      break;
    }
    points.push(index);
  }

  return points;
}

const rowSize = 15;
function Board(props) {
  const { userCamp = CAMP.NONE } = props;
  const [chessboard, setChessboard] = useState({
    grids: new Array(rowSize * rowSize).fill(CAMP.NONE),
    nowCamp: CAMP.WHITE,
  });
  const [winPath, setWinPath] = useState([]);
  const flagGrids = useMemo(() => {
    const gs = new Array(rowSize * rowSize).fill(false);
    winPath.forEach(index => gs[index] = true);
    return gs;
  }, [winPath]);

  useEffect(() => {
    const { nowCamp } = chessboard;
    if (nowCamp !== userCamp && nowCamp !== CAMP.NONE) {
      robotWork();
    }
  }, [chessboard]);

  const robotWork = () => {
    const { grids, nowCamp } = chessboard;
    const index = getRandomPos(grids);
    grids[index] = nowCamp;
    putPiece(index, nowCamp);
  }

  const putPiece = (index) => {
    const { grids, nowCamp } = chessboard;

    if (index < 0 ||
      index >= rowSize * rowSize) {
      return;
    }


    grids[index] = nowCamp;
    const winPath = judgeVictoryInPoint(grids, index);
    if (Array.isArray(winPath) && winPath.length >= 5) {
      handleWin(winPath);
      setChessboard({ ...chessboard, grids: [...grids], nowCamp: CAMP.NONE });
    } else {
      const nextCamp = getNextCamp(nowCamp);
      setChessboard({ ...chessboard, grids: [...grids], nowCamp: nextCamp });
    }
  }

  const handleWin = (winRule) => {
    console.log("winner");
    setWinPath(winRule);
    // 标记出棋子
  }

  const onClick = (index) => {
    const { nowCamp } = chessboard;
    if (nowCamp !== userCamp) {
      return;
    }

    putPiece(index);
  }

  return (
    <div className="board-wrapper">
      <BoardStatebar size={rowSize} />
      <div className="row">
        <BoardStatebar direction="column" size={rowSize} />
        {new Array(rowSize).fill(0).map((_, col) => (
          <div className="column" key={col}>
            {new Array(rowSize).fill(0).map((_, row) => <Grid key={row * rowSize + col} index={row * rowSize + col} state={chessboard.grids[row * rowSize + col]} flag={flagGrids[row * rowSize + col]} onClick={onClick} />)}
          </div>
        ))}
      </div>
    </div>
  );
}

export default Board;
